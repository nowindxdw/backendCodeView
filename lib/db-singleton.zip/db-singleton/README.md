### db-singleton

#### 更新历史
* v0.0.14
    1. 修复错误的error提示
* v0.0.13 
    1. 支持了多数据库schema的models文件初始化

#### 简述
基于[sequelize](http://www.sequelizejs.com)扩展了以下功能：

1. 单例模式，基于进程内唯一的单例实现
2. 支持多数据库，通过connectionPool的参数配置实现多数据库操作
3. 提供express middleware函数以获取sequelize对象
4. 当数据库不存在时，自动创建数据库(仅支持mysql数据库自动创建)


#### 参考资料

* [Sequelize Docs](http://docs.sequelizejs.com/en/v3/)
* [Creating a True Singleton in NodeJS](https://derickbailey.com/2016/03/09/creating-a-true-singleton-in-node-js-with-es6-symbols/)


#### Usage

```javascript
var dbConfig = {
    user: "database user"
    password: "database password",
    host: "db hostname",
    dialect: "mysql",
    maxConnection: 100,
    minConnection: 0,
    idle: 60
};

var db = DBSingleton(dbConfig, __dirname + '/models', "CloudDB_Schema");
db.sequelize('test').then(function(sequelize) {
    // do sequelize operations here
    // ...
});

var db2 = DBSingleton(dbConfig, __dirname + "/models_CustomerDB", "CustomerDB_Schema");
db2.sequelize("customerDB").then(function(sequelize){
    // do sequelize operations 
});

var db3 = DBSingleton(); // 可以自动重用'test'示例
db3.sequelize('test').then(function(sequelize){
    // do something else here
});

var db4 = DBSingleton(); // 自动重用'customerDB'示例
db4.sequelize('customerDB').then(function(sequelize){
    // do operations on customerDB
});


```