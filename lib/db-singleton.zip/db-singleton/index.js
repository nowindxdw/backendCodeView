/*****************************************************************
 * 青岛雨人软件有限公司2016版权所有
 *
 * 本软件之所有（包括但不限于）源代码、设计图、效果图、动画、日志、
 * 脚本、数据库、文档均为青岛雨人软件或其附属子公司所有。任何组织
 * 或者个人，未经青岛雨人软件书面授权，不得复制、使用、修改、分发、
 * 公布本软件的任何部分。青岛雨人软件有限公司保留对任何违反本声明
 * 的组织和个人采取法律手段维护合法权益的权利。
 *****************************************************************/

'use strict';

var fs = require('fs');
var path = require('path');
var Sequelize = require('sequelize');

var Logger = require("logger-romens");
var logger = new Logger({
    level: 'TRACE'
});

var defaultConfig = {
    charset: 'utf8',
    collate: 'utf8_general_ci',
    supportBigNumbers: true,
    bigNumberStrings: true
};

/**
 * Singleton implementation in ES6 Symbol
 */
const SINGLETONKEY = Symbol.for("db-singleton.npm.romenscd.cn");

var globalSymbols = Object.getOwnPropertySymbols(global);
if (globalSymbols.indexOf(SINGLETONKEY) < 0) {
    global[SINGLETONKEY] = {
        instances: {},
        dbConfig: {},
        schemas: {}
    };
}

var lodash = require('lodash');

/**
 * 初始化数据库实例对象
 * @param dbConfig  数据库连接参数, 可选, 再次引用时可不填写
 *        {
 *            "user": "root",                           # 数据库用户名
 *            "password": "dbpassword",                 # 数据库密码
 *            "host": "database server hostname or ip", # 数据库服务器
 *            "dialect": "mysql",                       # 可忽略，默认为mysql
 *            "maxConnection": 100,                     # 连接池最大连接数
 *            "minConnection": 0,                       # 连接池最小连接数
 *            "idle": 60                                # 默认释放数据库连接时长, 单位为秒
 *        }
 * @param modelPath 数据库定义文件路径，可选，再次引用时可以不填写
 * @param schemaName 数据库schema名称
 * @returns {*}
 *      返回实例对象
 *      {
 *          "seqeulize": A-Sequelize-Ojbect,
 *          "config": a-DB-config-Object
 *      }
 */
module.exports = function(dbConfig, modelPath, schemaName) {
    var core = global[SINGLETONKEY];

    // find out all model files
    if (modelPath && lodash.isEmpty(core.schemas[schemaName])) {
        core.schemas[schemaName] = [];
        var modelFiles = fs.readdirSync(modelPath).filter(function(file) {
            return ((file.indexOf('.') !== 0) && (file.slice(-3) === '.js') && (file[0] !== '_'));
        }).forEach(function(file) {
            core.schemas[schemaName].push(modelPath + "/" + file);
        });

        logger.debug("schema files=" + JSON.stringify(core.schemas[schemaName]));
    }

    var singleton = {
        sequelize: function(dbName) {
            // Set dbConfig
            if (dbConfig && core.dbConfig && !lodash.has(core.dbConfig, dbName)) {
                core.dbConfig[dbName] = dbConfig;
            }

            var promise = new Promise(
                function(resolve, reject) {
                    createDB(dbName, core)
                        .then(function() {
                            logger.debug("fetching sequlize object");
                            var sequelize = core.instances[dbName];
                            var dbConfig = core.dbConfig[dbName];

                            if (lodash.isEmpty(sequelize)) {
                                logger.info("Initializing sequelize instance for database <" + dbName + ">");

                                /**
                                 * Prepare db connection options
                                 */

                                // 加载配置文件中的dialect设置
                                var dialect = dbConfig.dialect;
                                var dialectOption = {
                                    charset: core.dbConfig.charset || defaultConfig.charset,
                                    collation: core.dbConfig.collate || defaultConfig.collate,
                                    supportBigNumbers: core.dbConfig.supportBigNumbers || defaultConfig.supportBigNumbers,
                                    bigNumberStrings: core.dbConfig.bigNumberStrings || defaultConfig.bigNumberStrings
                                };

                                var options = {
                                    host: dbConfig.host,
                                    dialect: dialect,
                                    dialectOptions: dialectOption,
                                    pool: {
                                        max: dbConfig.maxConnection | 10,
                                        min: dbConfig.minConnection | 0,
                                        idle: dbConfig.idle | 60
                                    },
                                    define: {
                                        underscored: false,
                                        freezeTableName: false,
                                        syncOnAssociation: true,
                                        timestamps: true
                                    }
                                };

                                logger.debug("dbConfig=" + JSON.stringify(dbConfig));
                                logger.debug("options=" + JSON.stringify(options));

                                /**
                                 * initiate the sequelize object
                                 */
                                var seq = new Sequelize(
                                    dbName,
                                    dbConfig.user,
                                    dbConfig.password,
                                    options
                                );


                                /**
                                 * import the models
                                 */
                                seq.models = importModels(seq, core.schemas[schemaName]);
                                core.instances[dbName] = seq;

                                /**
                                 * sync the model to db
                                 */
                                logger.trace("Syncing the tables ...");
                                seq.sync().then(function() {
                                    resolve(seq);
                                }).catch(function(err) {
                                    logger.error("Fail to sync tables, error:" + err.stack);
                                });
                            } else {
                                logger.info("sequelize object is not empty, taking the existing object");
                                resolve(sequelize);
                            }
                        })
                        .catch(function(err) {
                            if (err)
                                logger.error("db error: " + lodash.has(err, "stack") ? err.stack : err);
                            reject();
                        });
                }
            );
            return promise;
        }
    };
    return singleton;
};

var importModels = function(sequelize, modelFiles) {
    /**
     * import the models
     */
    var db = {};
    modelFiles.forEach(function(file) {
        logger.debug("importing model file: " + file);
        var model = sequelize.import(file);
        db[model.name] = model;
    });

    /**
     * link the association relationship
     */
    logger.trace("Associating...");
    Object.keys(db).forEach(function(modelName) {
        if (db[modelName].associate)
            db[modelName].associate(db);
    });

    return db;
};

/**
 * 创建数据库，如果不存在的话
 * @param dbName
 * @param core
 */
var createDB = function(dbName, core) {
    var mysql = require("mysql");

    var promise = new Promise(
        function(resolve, reject) {
            // check sequelize object
            if (lodash.has(core.instances, dbName))
                return resolve();

            var dbConfig = core.dbConfig[dbName];
            // support mysql only
            if (dbConfig.dialect !== "mysql")
                return reject();

            var pool = mysql.createPool({
                connectionLimit: 1,
                host: dbConfig.host,
                user: dbConfig.user,
                password: dbConfig.password,
                charset: dbConfig.charset || defaultConfig.charset,
                supportBigNumbers: dbConfig.bigNumberStrings || defaultConfig.supportBigNumbers,
                bigNumberStrings: dbConfig.bigNumberStrings || defaultConfig.bigNumberStrings
            });

            pool.query('CREATE DATABASE IF NOT EXISTS ' + dbName + ' DEFAULT CHARSET utf8 COLLATE utf8_general_ci;', function(err) {
                pool.end(function() {
                    if (err) {
                        logger.debug("Database is already existing, skip creating...");
                    } else {
                        logger.info("Database is created!");
                    }
                    resolve();
                });
            });
        }
    );

    return promise;

};