/*****************************************************************
 * 青岛雨人软件有限公司2016版权所有
 *
 * 本软件之所有（包括但不限于）源代码、设计图、效果图、动画、日志、
 * 脚本、数据库、文档均为青岛雨人软件或其附属子公司所有。任何组织
 * 或者个人，未经青岛雨人软件书面授权，不得复制、使用、修改、分发、
 * 公布本软件的任何部分。青岛雨人软件有限公司保留对任何违反本声明
 * 的组织和个人采取法律手段维护合法权益的权利。
 *****************************************************************/

var should = require('chai').should();
var sinon = require('sinon');
var async = require('async');
var DBSingleton = require("../index.js");
var Logger = require("logger-romens");
var logger = new Logger({
    level: 'TRACE'
});

describe("db-singleton unit tests", function(){
    var dbName = 'RecruitDB';
    var dbName2 = 'test2';
    var dbConfig = {
        user: "root",
        password: "100821",
        host: "localhost",
        dialect: "mysql",
        maxConnection: 100,
        minConnection: 0,
        idle: 60
    };

    after(function () {
    });

    //describe("#module", function(){
    //    it(".sequelize()", function(done){
    //        var dbSingleton = DBSingleton(dbConfig, __dirname + '/models', "schema1");
    //
    //        dbSingleton.sequelize(dbName).then(function(sequelize) {
    //            sequelize.should.be.an('object');
    //                dbSingleton.sequelize(dbName).then(function(sequelize2) {
    //                    sequelize.should.equal(sequelize2);
    //                    sequelize.should.not.equal({});
    //                    done();
    //                });
    //        });
    //    });
    //
    //    it(".sequelize()多次执行，检查是否重用", function(finish){
    //
    //        async.series([
    //            function step1(done) {
    //                var dbSingleton1 = DBSingleton(dbConfig, __dirname + "/models", "schema1");
    //                return dbSingleton1.sequelize(dbName).then(function (sequelize) {
    //                    sequelize.should.be.an('object');
    //                    console.log("step1 succeed");
    //                    done();
    //                });
    //            },
    //            function step2(done){
    //                var dbSingleton2 = DBSingleton(dbConfig, __dirname + "/models2", "schema2");
    //                return dbSingleton2.sequelize(dbName2).then(function (sequelize) {
    //                    sequelize.should.be.an('object');
    //                    console.log("step2 succeed");
    //                    done();
    //                });
    //            },
    //            function step3(done){
    //                var dbSingleton3 = DBSingleton();
    //                return dbSingleton3.sequelize(dbName).then(function (sequelize) {
    //                    sequelize.should.be.an('object');
    //                    console.log("step4 succeed");
    //                    done();
    //                });
    //            },
    //            function step4(done){
    //                var dbSingleton4 = DBSingleton();
    //                return dbSingleton4.sequelize(dbName2).then(function (sequelize) {
    //                    sequelize.should.be.an('object');
    //                    console.log("step4 succeed");
    //                    done();
    //                });
    //            }
    //        ], function(errs, done){
    //            if (!errs){
    //                finish();
    //            }
    //        });
    //    });
    //
    //    it(".sequelize() against other database than mysql", function(done){
    //        dbConfig.dialect = "sqlite";
    //        var dbSingleton = DBSingleton(dbConfig, __dirname + "/models", "schema1");
    //        dbSingleton.sequelize(dbName)
    //            .catch(function(){
    //                done();
    //            });
    //    });
    //});

    describe("#index", function(){

        it(".sequelize().init", function() {
            logger.trace(dbName);
            var dbSingleton = DBSingleton(dbConfig, '/home/dawei/WebstormProjects/Recruitments/schemas/cloudDB', "schema1");
            return dbSingleton.sequelize(dbName).then(function (sequelize) {
                   return sequelize.models.dbsingleton.findAll()
                       .then(function(result){
                         logger.debug(result);
                           return result;
                       });
            });
        });

        xit(".sequelize() upset ", function() {
            logger.trace(dbName);
            var dbSingleton = DBSingleton(dbConfig, __dirname + '/models', "schema1");
            var upsetData = {
                id   : "14879461654814154161",
                name : "中文名字"
            };
            return dbSingleton.sequelize(dbName).then(function (sequelize) {
                return sequelize.models.dbsingleton.upsert(upsetData)
                    .then(function(result){
                        logger.debug(result);
                        return sequelize.models.dbsingleton.findAll()
                            .then(function(selectData){
                                logger.debug(selectData);
                                return selectData;
                            });
                    });
            });
        });

        xit(".sequelize() drop ", function() {
            logger.trace(dbName);
            var dbSingleton = DBSingleton(dbConfig, __dirname + '/models', "schema1");
            return dbSingleton.sequelize(dbName).then(function (sequelize) {
                return sequelize.drop();
            });
        })
    });
});