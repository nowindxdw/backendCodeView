var expect = require('chai').expect;
var moment = require("moment");
var getMac = require("getmac");
var snowflake = require('../index');
var long = require("long");
var sinon = require('sinon');


describe("snowflakeid-romens", function(){
    before(function() {
    });

    after(function () {
        Math.random.restore();
        moment.now.restore();
        getMac.getMac.restore();
    });
    describe("#methods", function(){
        it(".next() - should generate a new id",function(done){
            /**
             * 替换Math.random(), 使之返回固定的值
             */
            sinon.stub(Math, "random", function(){ return 0.998;});
            sinon.stub(moment, "now", function(){ return 0x15555555555;});
            sinon.stub(getMac, "getMac", function(callback) {
                callback(null, "00:11:22:33:44:55");
            });

            snowflake.getSnowflakeIDFactory(function(err, id) {
                id.next();
                console.log(id);
                var binStr = id.high().toString(2) + id.low().toString(2);
                // 验证timestamp
                var ts = id.getTimestamp();
                expect(ts).to.equal(0x15555555555);
                // 验证hwId
                var hwId = id.getHwId();
                console.log(hwId);
                // 验证seqId
                var seqId = id.getSeqId();
                console.log('id.next1='+seqId);
                expect(seqId).to.equal(1022);
                // 验证seqId增加1
                id.next();
                console.log(id);
                seqId = id.getSeqId();
                console.log('id.next2='+seqId);
                expect(seqId).to.equal(1023);
                // 验证seqId增加1
                // 验证seqId增加1超过1023后自动回到0
                id.next();
                seqId = id.getSeqId();
                console.log('id.next3='+seqId);
                expect(seqId).to.equal(0);

                id.next();
                seqId = id.getSeqId();
                console.log('id.next4='+seqId);
                expect(seqId).to.equal(1);
                id.next();
                seqId = id.getSeqId();
                console.log('id.next5='+seqId);
                expect(seqId).to.equal(2);
                id.next();
                seqId = id.getSeqId();
                console.log('id.next6='+seqId);
                expect(seqId).to.equal(3);
                id.next();
                seqId = id.getSeqId();
                console.log('id.next7='+seqId);
                expect(seqId).to.equal(4);
                id.next();
                seqId = id.getSeqId();
                console.log('id.next8='+seqId);
                expect(seqId).to.equal(5);
                id.next();
                seqId = id.getSeqId();
                console.log('id.next9='+seqId);
                expect(seqId).to.equal(6);
                id.next();
                seqId = id.getSeqId();
                console.log('id.next10='+seqId);
                expect(seqId).to.equal(7);
                id.next();
                seqId = id.getSeqId();
                console.log('id.next11='+seqId);
                expect(seqId).to.equal(8);
                id.next();
                seqId = id.getSeqId();
                console.log('id.next12='+seqId);
                expect(seqId).to.equal(9);
                id.next();
                seqId = id.getSeqId();
                console.log('id.next13='+seqId);
                expect(seqId).to.equal(10);
                done();
            });
        });
    });
    describe("#promise test", function(){
        it("promise", function(done){
            snowflake.getSnowflakeIDPromise().then(function(id){
                console.log(id);
                expect(id).not.equal("");
                done();
            });
        });
    });
    describe("#humanReadable test", function(){
        it("toHumanReadable", function(done){
            var hrStr = snowflake.toHumanReadable("12491575082415873361");
            expect(hrStr).to.equal("AUP-QXBAR-89QAH");
            expect(snowflake.fromHumanReadable(hrStr).toString(10)).to.equal('12491575082415873361');
            done();
        });
    });
});