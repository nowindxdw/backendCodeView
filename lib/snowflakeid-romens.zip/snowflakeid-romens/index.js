/**
 * index.js
 *
 * Snowflake ID generator
 *
 */
var BASE = process.cwd();

var long = require("long");
var moment = require("moment");
var _ = require('lodash');
var getMac = require("getmac");

/**
 * Singleton Reference
 * @type {null}
 */
var snowflakeIDGenRef = null;
var macId = 0x00;
var processId = process.pid;
var hwId=0x0;

/**
 * 可读格式的翻译对照表
 *
 */
var humanReadableTable  = {
    '00000': '0',
    '00001': '1',
    '00010': '2',
    '00011': '3',
    '00100': '4',
    '00101': '5',
    '00110': '6',
    '00111': '7',
    '01000': '8',
    '01001': '9',
    '01010': 'A',
    '01011': 'B',
    '01100': 'C',
    '01101': 'D',
    '01110': 'E',
    '01111': 'F',
    '10000': 'G',
    '10001': 'H',
    '10010': 'J',
    '10011': 'K',
    '10100': 'M',
    '10101': 'N',
    '10110': 'P',
    '10111': 'Q',
    '11000': 'R',
    '11001': 'T',
    '11010': 'U',
    '11011': 'V',
    '11100': 'W',
    '11101': 'X',
    '11110': 'Y',
    '11111': 'Z'
};
var invertHumanReadable = _.invert(humanReadableTable);

/**
 * 将sfId转换成可读的短格式字符串
 * @param sfId
 * @return 可读格式的数字
 * @example
 *      var sfId = '12491575082415873361';
 *      var hrStr = toHumanReadable(sfId);
 *      console.log(hrStr);     // "AUP-QNZUX-0917Z'
 */
var toHumanReadable = function(sfId){
    var id = sfId;
    // 生成64位字符串
    if (_.isString(sfId)){
        id = long.fromString(sfId, true, 10);
    }
    var binStr = id.toString(2);

    // 强制补全为65位
    binStr = '0' + binStr;

    // 按照2^32, 每5bits分解
    var binKeys = binStr.match(/.{1,5}/g);

    var out = '';

    for (var i=0; i < binKeys.length; i++){
        // 生成 AUP-QNZUX-0917Z 的短线
        if (i==3 || i==8)
            out += "-";
        out += humanReadableTable[binKeys[i]];
    }

    return out;
};

/**
 * 将短格式还原成sfId
 * @param hrStr
 * @return 64位整数格式
 * @example
 *      var vipID = "AUP-QNZUX-0917Z';
 *      var sfId = fromHumanReadable(vipId);
 *      console.log(sfId.toString(10));     // 按照10进制输出, 12491575082415873361
 */
var fromHumanReadable = function(hrStr){
    // 全部转换成大写字母
    hrStr = hrStr.toUpperCase();

    // 取出所有可用的字符格式
    var keys = _.keys(invertHumanReadable);
    var binStr = '';
    for (var i=0; i<hrStr.length; i++){
        if (keys.indexOf(hrStr[i]) >= 0)
            binStr += invertHumanReadable[hrStr[i]];
    }
    var sfId = long.fromString(binStr, true, 2);
    return sfId;
};

var getSnowflakeIDPromise = function() {
    var promise = new Promise(function(resolve, reject){
        getSnowflakeIDGen(function(err, idGen){
            if (err) {
                reject(err);
            } else {
                resolve(idGen.next());
            }
        });
    });

    return promise;
};

/**
 * 获取SnowflakeIDGenerator的singleton
 * @returns {null}
 */
var getSnowflakeIDGen = function(callback){
    if (!snowflakeIDGenRef)
        snowflakeIDGenRef = new SnowflakeID();

    if (!macId) {
        getMac.getMac(function(err, mac){
            if (!err) {
                var macArray = mac.split(":");
                macId = parseInt(macArray[5], 16);
                hwId = ((macId << 3) | (processId & 0x7)) & 0x3FF;
            }
            callback(err, snowflakeIDGenRef);
        });
    }
    else
        callback(null, snowflakeIDGenRef);

    return snowflakeIDGenRef;
};

/**
 * Snowflake 构造函数
 * @constructor
 */
function SnowflakeID() {
    var rand = Math.random();
    this.seqId = Math.floor(rand * 1024);
    this.shardId = 0x0;
}

/**
 * 获取下一个ID
 * @param uInstanceId           实例id，全系统唯一值，如果为空，则使用MAC地址后10位
 * @returns {SnowflakeID}
 */
SnowflakeID.prototype.next = function(uInstanceId) {
    var self = this;

    // get timestamp 41bits, epoch time since 1970-01-01 00:00:00.000 in mS
    var value = (long.fromNumber(moment.now(), true)).shiftLeft(64-41);

    // increase seqId
    self.shardId = (++self.shardId) & 0x07;
    self.seqId = (++self.seqId) & 0x3FF;

    value =  value.or((hwId << 13) | (self.shardId << 10) | self.seqId);

    self.value = value;
    return self;
};

/**
 * 转换成字符串
 * @param base
 * @returns {string}
 */
SnowflakeID.prototype.toString = function(base) {
    return this.value.toString(base);
};

SnowflakeID.prototype.toHumanReadable = function() {

};

SnowflakeID.prototype.high = function(){
    return this.value.getHighBitsUnsigned();
};

SnowflakeID.prototype.low = function(){
    return this.value.getLowBitsUnsigned();
};

/**
 * 从一个snowflakeId解析出时间戳
 * @returns {number}
 */
SnowflakeID.prototype.getTimestamp = function(snowflakeIdString) {
    var value = this.value;
    if (snowflakeIdString)
        value = (long.fromString(snowflakeIdString, true));
    value = value.shiftRightUnsigned(23);
    return value.toNumber();
};

SnowflakeID.prototype.getHwId = function(snowflakeIdString) {
    var value = this.value;
    if (snowflakeIdString)
        value = long.fromString(snowflakeIdString, true);
    var out = (value.shiftLeft(41).shiftRightUnsigned(41+13)).getLowBitsUnsigned();
    return out;

};

SnowflakeID.prototype.getShardId = function(snowflakeIdString){
    var value = this.value;
    if (snowflakeIdString)
        value = (long.fromString(snowflakeIdString,true));
    value = value.and(long.fromNumber(0x7<<10, true)).shiftRightUnsigned(10);
    return value.toNumber();
};


SnowflakeID.prototype.getSeqId = function(snowflakeIdString){
    var value = this.value;
    if (snowflakeIdString)
        value = (long.fromString(snowflakeIdString, true));
    value = value.and(long.fromNumber(0x7FF, true));
    value = value.toNumber()
    return value%1024;
};

var snowflakeIDFactory = {
    getSnowflakeIDFactory: getSnowflakeIDGen,
    getSnowflakeIDPromise: getSnowflakeIDPromise,
    toHumanReadable: toHumanReadable,
    fromHumanReadable: fromHumanReadable
};

module.exports = snowflakeIDFactory;