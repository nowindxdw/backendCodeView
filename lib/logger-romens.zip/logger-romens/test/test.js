var expect = require('chai').expect;
var Logger = require('../index');
var sinon = require('sinon');

describe("Logger", function () {

  var LOG_LEVEL = {
    trace: 'TRACE',
    debug: 'DEBUG',
    info: 'INFO',
    warn: 'WARN',
    error: 'ERROR',
    fatal: 'FATAL'
  };

  describe("#constructor()", function () {
    it("should return instance, when call with level & printer.", function () {
      var printer = function () {};
      var option = {
        level: LOG_LEVEL.debug,
        printer: printer,
        isColorful: false
      };
      var logger = new Logger(option);
      var isLogger = logger instanceof Logger;

      expect(isLogger).to.equal(true);
      expect(logger.level).to.equal(1);
      expect(logger.printer).to.equal(printer);
      expect(logger.isColorful).to.equal(false);
    });

    it("should get a TRACE level instance, when call without args.", function () {
      var logger = new Logger();
      var isLogger = logger instanceof Logger;

      expect(isLogger).to.equal(true);
      expect(logger.level).to.equal(0);
      expect(typeof logger.printer).to.equal('function');
      expect(logger.isColorful).to.equal(true);
    });
  });

  describe("#method()", function () {
    it("should called once printer when call trace", function () {
      var level = LOG_LEVEL.trace;
      var printer = sinon.spy();
      var isColorful = false;
      var option = {
        level: level,
        printer: printer,
        isColorful: isColorful
      };
      var logger = new Logger(option);
      logger.trace('ABC');
      expect(printer.calledOnce).to.equal(true);
    });

    it("should called once prnter then call trace", function () {
      var level = LOG_LEVEL.trace;
      var printer = sinon.spy();
      var isColorful = false;
      var option = {
        level: level,
        printer: printer,
        isColorful: isColorful
      };
      var logger = new Logger(option);
      logger.trace('ABC', 'DEF');
      expect(printer.calledOnce).to.equal(true);
    });

    var a = [
      {
        level: 'TRACE',
        func: 'trace',
        key: 'name',
        value: {
          name: 'zhaopeng',
          age: 24
        }
      },
      {
          level: 'TRACE',
          func: 'enter',
          key: 'enter function print',
          value: null
      },
      {
          level: 'TRACE',
          func: 'footprint',
          key: 'footprint',
          value: null
      },
      {
        level: 'TRACE',
        func: 'sql',
        key: 'this is a sql string',
        value: {
          name: 'zhaopeng',
          age: 24
        }
      },
      {
        level: 'TRACE',
        func: 'sqlError',
        key: new Error('this is a sql error'),
        value: {
          name: 'zhaopeng',
          age: 24
        }
      },
      {
        level: 'TRACE',
        func: 'debug',
        key: 'name',
        value: {
          name: 'zhaopeng',
          age: 24
        }
      },
      {
        level: 'TRACE',
        func: 'info',
        key: 'name',
        value: {
          name: 'zhaopeng',
          age: 24
        }
      },
      {
        level: 'TRACE',
        func: 'warn',
        key: 'name',
        value: {
          name: 'zhaopeng',
          age: 24
        }
      },
      {
        level: 'TRACE',
        func: 'error',
        key: new Error(' this is a error ')
      },
      {
        level: 'TRACE',
        func: 'fatal',
        key: new Error(' this is a error ')
      },
      {
        level: 'TRACE',
        func: 'errorWithStack',
        key: new Error('test ERROR')
      }
    ];

    a.forEach(function (obj) {

      it('call ' + obj.func, function () {
        var level = obj.level;
        var printer = sinon.spy();
        var option = {
          level: level,
          printer: printer
        };
        var logger = new Logger(option);

        var o = Object.getPrototypeOf(logger);

        o[obj.func].call(logger, obj.key, obj.value);

        expect(printer.calledOnce).to.equal(true);
      });
    });
  });
});