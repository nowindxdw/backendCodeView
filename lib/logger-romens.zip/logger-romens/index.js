var base = process.cwd();

var stackTrace = require("stack-trace");

var COLOR_WHITE = '\033[0m';
var COLOR_RED = '\033[31m';
var COLOR_GREEN = '\033[32m';
var COLOR_ORANGE = '\033[33m';
var COLOR_BLUE = '\033[34m';
var COLOR_PURPLE = '\033[35m';

function Logger(arg) {
  var option = arg || {};
  var level = option.level || 'TRACE';
  var printer = option.printer;
  var isColorful = option.isColorful;

  if (typeof printer !== 'function') {
    printer = undefined;
  }

  if (typeof isColorful !== 'boolean') {
    isColorful = true;
  }

  this.level = setLevel(level);
  this.printer = printer || defaultPrinter;
  this.isColorful = !!isColorful;
}

Logger.prototype.trace = function (key, value) {
  var myTag = 'TRACE';
  var myLevel = 0;
  var myColor = COLOR_GREEN;
  var printer = this.printer;
  var level = this.level;
  var isColorful = this.isColorful;

  if (level > myLevel) {
    return;
  }
  if (!isColorful) {
    myColor = '';
  }
  printer(combineMsg(myColor, myTag, key, value));
};

Logger.prototype.enter = function() {
    var myTag = 'TRACE ENTER';
    var myLevel = 0;
    var myColor = COLOR_GREEN;
    var printer = this.printer;
    var level = this.level;
    var isColorful = this.isColorful;

    if (level > myLevel) {
        return;
    }
    if (!isColorful) {
        myColor = '';
    }
    printer(combineMsg(myColor, myTag, 'entering function ...'));
};

Logger.prototype.footprint = function() {
    var myTag = 'FOOTPRIINT';
    var myLevel = 0;
    var myColor = COLOR_RED;
    var printer = this.printer;
    var level = this.level;
    var isColorful = this.isColorful;

    if (level > myLevel) {
        return;
    }
    if (!isColorful) {
        myColor = '';
    }
    printer(combineMsg(myColor, myTag, 'footprint'));
};

Logger.prototype.sql = function (sql) {
  var myTag = 'TRACE SQL';
  var myLevel = 0;
  var myColor = COLOR_BLUE;
  var printer = this.printer;
  var level = this.level;
  var isColorful = this.isColorful;

  if (level > myLevel) {
    return;
  }
  if (!isColorful) {
    myColor = '';
  }
  printer(combineMsg(myColor, myTag, 'sql', sql));
};

Logger.prototype.sqlError = function (err) {
  var myTag = 'ERROR SQL';
  var myLevel = 5;
  var myColor = COLOR_PURPLE;
  var printer = this.printer;
  var level = this.level;
  var isColorful = this.isColorful;

  if (level > myLevel) {
    return;
  }
  if (!isColorful) {
    myColor = '';
  }
  var temp = "SQL Error: " + err + ", stack trace: " + err.stack;
  printer(combineMsg(myColor, myTag, 'sql error', temp));
};

Logger.prototype.debug = function (key, value) {
  var myTag = 'DEBUG';
  var myLevel = 1;
  var myColor = COLOR_ORANGE;
  var printer = this.printer;
  var level = this.level;
  var isColorful = this.isColorful;

  if (level > myLevel) {
    return;
  }
  if (!isColorful) {
    myColor = '';
  }
  printer(combineMsg(myColor, myTag, key, value));
};

Logger.prototype.info = function (key, value) {
  var myTag = 'INFO';
  var myLevel = 2;
  var myColor = COLOR_WHITE;
  var printer = this.printer;
  var level = this.level;
  var isColorful = this.isColorful;

  if (level > myLevel) {
    return;
  }
  if (!isColorful) {
    myColor = '';
  }
  printer(combineMsg(myColor, myTag, key, value));
};

Logger.prototype.warn = function (key, value) {
  var myTag = 'WARN';
  var myLevel = 3;
  var myColor = COLOR_BLUE;
  var printer = this.printer;
  var level = this.level;
  var isColorful = this.isColorful;

  if (level > myLevel) {
    return;
  }
  if (!isColorful) {
    myColor = '';
  }
  printer(combineMsg(myColor, myTag, key, value));
};

Logger.prototype.error = function (err) {
  var myTag = 'ERROR';
  var myLevel = 4;
  var myColor = COLOR_PURPLE;
  var printer = this.printer;
  var level = this.level;
  var isColorful = this.isColorful;

  if (level > myLevel) {
    return;
  }
  if (!isColorful) {
    myColor = '';
  }

  printer(combineMsg(myColor, myTag, 'error', err));
};

Logger.prototype.fatal = function (key, value) {
  var myTag = 'FATAL';
  var myLevel = 5;
  var myColor = COLOR_RED;
  var printer = this.printer;
  var level = this.level;
  var isColorful = this.isColorful;

  if (level > myLevel) {
    return;
  }
  if (!isColorful) {
    myColor = '';
  }
  printer(combineMsg(myColor, myTag, key, value));
};

Logger.prototype.errorWithStack = function (err) {
  var myTag = 'ERRORWITHSTACK';
  var myLevel = 4;
  var myColor = COLOR_PURPLE;
  var printer = this.printer;
  var level = this.level;
  var isColorful = this.isColorful;

  if (level > myLevel) {
    return;
  }
  if (!isColorful) {
    myColor = '';
  }
  var value = "Error: " + err + ", stack trace: " + err.stack;
  printer(combineMsg(myColor, myTag, 'error', value));
};

function defaultPrinter(msg) {
  console.log(msg);
}

function setLevel(level) {
  var obj = {
    TRACE: 0,
    DEBUG: 1,
    INFO: 2,
    WARN: 3,
    ERROR: 4,
    FATAL: 5
  };

  var level = obj[level] || 0;
  return level;
}

function combineMsg(color, prefix, key, value) {
  if (value === undefined) {
    value = key;
    key = '-';
  }
  if (typeof value !== 'string') {
    value = JSON.stringify(value);
  }

  var stack = stackTrace.get();
  var caller = stack[2];
  var defaultColor = COLOR_WHITE;
  if (color === '') {
    defaultColor = '';
  }

  return color +
    "[" + prefix + "]" + defaultColor +
    "[" + timestamp() + "]" +
    "[" + caller.getFileName().replace(base, '') + ":" + caller.getLineNumber() + "]" +
    "[" + caller.getFunctionName() + "] " +
    color + "[" + key + ':' + value + ']' + defaultColor;
}

function timestamp() {
  var ts_hms = new Date();
  return ts_hms.getFullYear() + '-' +
    ("0" + (ts_hms.getMonth() + 1)).slice(-2) + '-' +
    ("0" + (ts_hms.getDate())).slice(-2) + ' ' +
    ("0" + ts_hms.getHours()).slice(-2) + ':' +
    ("0" + ts_hms.getMinutes()).slice(-2) + ':' +
    ("0" + ts_hms.getSeconds()).slice(-2) + '.' +
    ("000" + ts_hms.getMilliseconds()).slice(-3);
}

module.exports = Logger;
