# logger-romens change log

## v0.0.1 2016-09-20
* fix bug: add dependence `stack-trace` to package.json
* add change-log.md
* update document: add user guide to readme
