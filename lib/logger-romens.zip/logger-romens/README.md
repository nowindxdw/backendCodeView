# logger-romens

用来打印调试日志的模块.
日志可以设置不同的级别,可以扩展的打印输出,可以选择打印时是否使用颜色选项.

##### 作者:zhaopeng

## user guide


### install

先确保npm使用了雨诺的私有源.如果npm没有指向成都雨诺的私有源,请执行下面命令(其中地址信息请先确认):
```shell
npm set registry http://192.168.100.1:4873
```
### use

#### 最简单使用方式

```javascript
var Logger = require('logger-romens');
var logger = new Logger();

logger.trace('myKey', 'myValue');
// 输出如下:
// [TRACE][2016-09-21 15:04:10.956][/test/test.js:69][null] [myKey:myValue]

```

我们可以省略key
```javascript
logger.trace('myValue');
// [TRACE][2016-09-21 15:04:10.956][/test/test.js:69][null] [-:myValue]
```


其他调用方法:
```javascript
logger.sql('mySQL');
logger.sqlError(errorObject);
logger.debug('myKey', 'myValue');
logger.info('myKey', 'myValue');
logger.warn('myKey', 'myValue');
logger.error(errorObject);
logger.fatal('myKey', 'myValue');
logger.errorWithStack(errorObject);
```
以上所有的key都可以省略

#### OPTION

logger类接收`option`以控制不同的行为

```javascript

var logLevel = "TRACE";
var printer = function (msg) {
  var prefix = 'development logger: ';
  console.log(prefix + msg);
};

var option = {
  level: logLevel,
  printer: printer,
  isColorful: false
};

var logger = new Logger(option);

logger.trace('myKey', 'myValue');
// 输出如下:
// development logger: [TRACE][2016-09-21 15:04:10.956][/test/test.js:69][null] [myKey:myValue]

```
* level

其中level用于控制logger打印的等级, 等级分布如下:

| 等级 | 级别 | 方法 |
| --- | --- | --- |
| TRACE | 0 | trace |
| TRACE | 0 | sql |
| DEBUG | 1 | debug |
| INFO  | 2 | info |
| WARN  | 3 | warn |
| ERROR | 4 | error |
| ERROR | 4 | sqlError |
| ERROR | 4 | errorWithStack |
| FATAL | 5 | fatal |

当设置一个级别后,低于此级别的日志不会打印出来

* printer

用与改变日志输出,可以地定义日志的输出方式

* isColorful

用与设置打印日志是否使用色彩(色彩仅在shell中有效)
