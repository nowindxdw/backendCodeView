# cache-server-factory-romens

用来获取和存储redis连接的模块.

##### 作者:zhaopeng
## user guide
### install

先确保npm使用了雨诺的私有源.如果npm没有指向成都雨诺的私有源,请执行下面命令(其中地址信息请先确认):
```shell
npm set registry http://192.168.100.1:4873
```
### use

```javascript
var CacheServerFactory = require('cache-server-factory-romens');
var RedisConnectionFactory = require('redis-connection-factory-romens');

var option = {
  "host" :'localhost',
  "port": 1234,
  "password": '1234',
  "database-number": 10
};
var redisConnection = RedisConnectionFactory.getRedisConnection(option);

var prefix = 'CachePrefix_';
var cacheServer = CacheServerFactory.getCacheServer(prefix, redisConnection);

```
cacheServerFactor.getCacheServer方法的参数需要一个redisConnection对象



cacheServer的调用:
```javascript
cacheServer.save(keyName, value, ttl);

cacheServer.setTTL(keyName, ttl);

cacheServer.find(keyName, function(error, result) {
  // ...
});

cacheServer.remove(keyName, function(error) {
  // ...
});

// #cacheCount
// 用于缓存一个filter对应的数据
var filter = {
  // some properties
};
var getCount =  function(f) {
   var count  = null;
   // get count from db or ...
   var err = null;
   // count type: number
   return f(err, count);
}
catchServer.cacheCount(filter, countFunction, ttl, function (err, count) {
    // count type: number

});

// filter可以是统计条件组成度对象，但是需要注意可能不同的业务系统可能出现同结构的对象导致数据干扰。建议加上业务系统特定的tag
// filter 也可以接受一个md5之后的字符串
// countFunction的调用方式：countFunction(f)；要求countFunction内部必须调用f：f（err，number）
// ttl ：秒
```
* 其中save方法可以省略参数`ttl`,表示永久有效
* `save`方法与`setTTL`方法都会返回布尔值,表示操作是否成功

## changelog
从[这里](http://git.cd.romens.cn/npm/cache-server-factory-romens/blob/master/change-log.md)找到change log