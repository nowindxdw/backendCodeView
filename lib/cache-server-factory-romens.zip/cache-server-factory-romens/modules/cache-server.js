var _ = require('lodash');
var md5 = require('js-md5');

function CacheServer (keyNamePrefix, redisConnection) {
  this.keyNamePrefix = keyNamePrefix;
  this.redisConnection = redisConnection;
}

CacheServer.prototype.remove = function (key, f) {
  var redisConnection = this.redisConnection;
  var keyNamePrefix = this.keyNamePrefix;

  var realKeyName = keyNamePrefix + key;
  redisConnection.del(realKeyName, function (error) {
    if (error) {
      return f(error);
    }
    f(null);
  });
};

CacheServer.prototype.find = function (key, f) {
  var redisConnection = this.redisConnection;
  var keyNamePrefix = this.keyNamePrefix;

  if (typeof key !== "string" || key.length === 0) {
    var err = new Error("invalid input type");
    return f(err);
  }

  var realKeyName = keyNamePrefix + key;
  redisConnection.get(realKeyName, function (error, value) {
    if (error) {
      return f(error);
    }
    f(null, value);
  });
};

CacheServer.prototype.save = function (key, value, ttl) {
  var redisConnection = this.redisConnection;
  var keyNamePrefix = this.keyNamePrefix;

  if (typeof key !== "string" || key.length < 1 || typeof ttl !== "number") {
    return false;
  }

  if (typeof value === "object") {
    value = JSON.stringify(value);
  }

  var realKeyName = keyNamePrefix + key;
  redisConnection.set(realKeyName, value);
  if (typeof ttl === "number") {
    redisConnection.expire(realKeyName, ttl);
  }
  return true;
};

CacheServer.prototype.setTTL = function (key, ttl) {
  var redisConnection = this.redisConnection;
  var keyNamePrefix = this.keyNamePrefix;

  if (typeof key !== "string" || key.length < 1 || typeof ttl !== "number") {
    return false;
  }

  var realKeyName = keyNamePrefix + key;
  redisConnection.expire(realKeyName, ttl);
  return true;
};

CacheServer.prototype.saveList = function(key, array, ttl, f) {
  var redisConnection = this.redisConnection;
  var keyNamePrefix = this.keyNamePrefix;

  if (!(isLegalKey(key) && _.isArray(array))) {
    var err = new Error("Invalid key!");
    return f(err);
  }

  var realKeyName = keyNamePrefix + key;
  redisConnection.lpush(realKeyName, array, function (err, result) {
    if (err) {
      return f(err);
    }
    if (isLegalTtl(ttl)) {
      redisConnection.expire(realKeyName, ttl);
    }
    f(null, result);
  });
}

CacheServer.prototype.getList = function(key, start, end, f) {
  var redisConnection = this.redisConnection;
  var keyNamePrefix = this.keyNamePrefix;

  if (!isLegalKey(key)) {
    var err = new Error("Invalid key!");
    return f(err);
  }

  var realKeyName = keyNamePrefix + key;
  redisConnection.lrange(realKeyName, start, end, function (err, result) {
    if (err) {
      return f(err);
    }
    f(null, result);
  });
}

CacheServer.prototype.saveSet = function (key, array, ttl, f) {
  var redisConnection = this.redisConnection;
  var keyNamePrefix = this.keyNamePrefix;

  if (!(isLegalKey(key) && _.isArray(array))) {
    var err = new Error("Invalid key!");
    return f(err);
  }

  var realKeyName = keyNamePrefix + key;
  redisConnection.sadd(realKeyName, array, function (err, result) {
    if (err) {
      return f(err);
    }
    if (isLegalTtl(ttl)) {
      redisConnection.expire(realKeyName, ttl);
    }
    f(null, result);
  });
}

CacheServer.prototype.isExistInSet = function (key, value, f) {
  var redisConnection = this.redisConnection;
  var keyNamePrefix = this.keyNamePrefix;

  if (!isLegalKey (key)) {
    var err = new Error("Invalid key!");
    return f(err);
  }

  var realKeyName = keyNamePrefix + key;
  redisConnection.sismember(realKeyName, value, function (error, value) {
    if (error) {
      return f(error);
    }
    f(null, value);
  });
}

/**
 * 缓存数据库统计结果
 * @param filter （object）
 * @param countFunction （function）
 * @param ttl （sec）
 * @param f （callback）
 */
CacheServer.prototype.cacheCount = function(filter, countFunction,ttl, f) {
  var self = this;

  var md5Tag = filter;
  if(typeof filter ===  'object') {
    md5Tag = md5(JSON.stringify(filter));
  }

  self.find(md5Tag, function (err, result) {
    if(err) {
      return f(err);
    }
    if (result !== null) {
      f(null, Number(result));
      return self.setTTL(md5Tag, ttl);
    }
    countFunction(function (err, result) {
      if(err) {
        return f(err);
      }
      if(typeof result !== 'number') {
        return f(new Error('countFunction 回调参数不正确'));
      }
      self.save(md5Tag, result.toString(), ttl);
      f(null, result);
    });
  });
};

function isLegalKey (key) {
  return !(typeof key !== "string" || key.length < 1);
}

function isLegalTtl (ttl) {
  return typeof ttl === "number"
}

module.exports = CacheServer;