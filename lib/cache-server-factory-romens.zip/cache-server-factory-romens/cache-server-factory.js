var CacheServer = require('./modules/cache-server.js');

var cacheServerRef = null;
var getCacheServer = function (keyNamePrefix, redisConnection) {
  if (cacheServerRef) {
    return cacheServerRef;
  }
  if (redisConnection === undefined) {
    redisConnection = keyNamePrefix;
    keyNamePrefix = '';
  }
  cacheServerRef = new CacheServer(keyNamePrefix, redisConnection);
  return cacheServerRef;
};

var CacheServerFactory = {
  getCacheServer: getCacheServer
};

module.exports = CacheServerFactory;