/**
 * Created by dawei on 17-3-9.
 */

var Kue = require('../kue.js');
var option = {
    prefix : 'q',
    redis  : {
        host: 'cd',
        port: 6379,
        db: 1, // if provided select a non-default redis db
        options: {
            // see https://github.com/mranney/node_redis#rediscreateclient
        }
    },
    UIport:3050,
    attempts:3
};
var kue = new Kue(option);
var key = 'testKue';
var data = {
    title: 'converting erpmsg into edi db',
    user: 1,
    ids:[11,22,33,44,55]
};
var job =kue.createQueue(key,data);
var job2 =kue.createQueue(key,data);
var job3 =kue.createQueue(key,data);
//任务的监听
job.on('complete', function(result){
    console.log("Job completed with data ", result);
}).on('failed', function(){
    console.log("Job failed");
}).on('progress', function(progress){
    process.stdout.write('\r  job #' + job.id + ' ' + progress + '% complete');
});
var jobs = kue.getJobs();//获取所有jobs的对象（其实是kue的单例对象）


//Failure Backoff 重试策略
job.attempts(3).backoff(true);//默认重试策略，越快越好
job.attempts(3).backoff( {delay: 60*1000, type:'fixed'} );//每一分钟重试一次,一共重试3次

//队列的执行
var exec = true;

jobs.process(key,function(job,done){
    console.log('[info] Task:'+job.type+'#'+job.id+' has been executed successful!');
    //DONE之前可以做你想要做的事情
    job.log('[info] Task:'+job.type+'#'+job.id+' has been executed');//这个log写入了redis记录
    console.log(job.data.ids);
    var len = job.data.ids.length;
    //循环处理数据
    function next(i) {
        setTimeout(function(){
            job.progress(i, len);//展示执行进度（单个执行任务内）
            //if(i%2 ==0){
            //    return done('set taskid='+job.id+' failed');
            //}
            if(i ==len)
                done(null,'all '+len+' tasks finished'); //千万别忘记调用此方法
            else
                next(i+1);
        },3000);
    }
    next(0);
});



jobs.process(key,function(job,done){
    console.log('[info] Task:'+job.type+'#'+job.id+' has been executed now successful!');
    done();
})

jobs.process(key,function(job,done){
    console.log('[info] Task:'+job.type+'#'+job.id+' has been executed now2 successful!');
    done();
})