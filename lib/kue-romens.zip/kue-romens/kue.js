var kue = require("kue");
var _ = require('lodash');

function Kue(arg) {
    console.log(arg);
    var option = arg || {};
    var prefix = option.prefix || 'q';
    var redis = option.redis;
    var UIport = option.UIport||3050;
    if (typeof redis !== 'object'|| _.isEmpty(redis)) {
        throw new Error('input arg redis config is empty')
    }
    this.prefix = prefix;
    this.redis = redis;
    this.queue = kue.createQueue({
        prefix:this.prefix,
        redis:this.redis
    });
    this.Job = kue.Job;
    //重试次数
    this.attempts = option.attempts||1;
    if(UIport>0){
        kue.app.listen(UIport);
        console.log('UI started on port '+UIport);
    }
}
//数据插入队列
Kue.prototype.createQueue = function (key,data,ttl) {
    //console.log('create:'+key);
    var queue = this.queue;
    var attempts = this.attempts
    var ttlms = ttl||3600000;
    var job = queue.create(key,data).ttl(ttlms).attempts(attempts).save(function(err){
        if(!err){
            console.log('job created success'+job.id)
        }
    }
    );
    return job;
};
//获取队列对象
Kue.prototype.getJobs = function () {
    console.log('get jobs ');
    return kue.createQueue();
};


//Graceful Shutdown
//
//Queue#shutdown([timeout,] fn) signals all workers to stop processing after their current active job is done. Workers will wait timeout milliseconds for their active job's done to be called or mark the active job failed with shutdown error reason. When all workers tell Kue they are stopped fn is called.
//process.once( 'SIGTERM', function ( sig ) {
//    shut down queue
//})
Kue.prototype.shutDownQueue = function (ttl) {
    var queue = this.queue;
    var ttl = ttl||5000;
    queue.shutdown( ttl, function(err) {
        console.log( 'Kue shutdown: ', err||'' );
    });
};

module.exports = Kue;

