### kue的封装

#### 关于kue
Kue is a priority job queue backed by redis, built for node.js.
[github的kue项目链接](https://github.com/Automattic/kue)
#### 使用方法

```
var Kue = require('kue-romens');
var option = {
    prefix : 'q',
    redis  : {
        host: 'cd',
        port: 6379,
        db: 1, // if provided select a non-default redis db
        options: {
            // see https://github.com/mranney/node_redis#rediscreateclient
        }
    },
    UIport:3050//可选参数，默认3050；队列消息的ui端口,传-1（小于0的任意值）则关闭UI界面
    attempts:3//可选参数，默认1次
};
var kue = new Kue(option);
var key = 'testKue';
var data = {
    title: 'converting erpmsg into edi db',
    user: 1,
    ids:[11,22,33,44,55]
};

//写入redis队列
var job =kue.createQueue(key,data);
//队列的执行
var jobs = kue.getJobs();
jobs.process(key,function(job,done){
    console.log('[info] Task:'+job.type+'#'+job.id+' has been executed successful!');
    //DONE之前可以做你想要做的事情
    console.log(job.data.ids);
    job.log('[info] Task:'+job.type+'#'+job.id+' has been executed');//这个log写入了redis记录
    done(); //千万别忘记调用此方法
});


更多使用例子参考/test/test.js
```
### 重试策略
```
    // Honor job's original delay (if set) at each attempt, defaults to fixed backoff
    job.attempts(3).backoff( true )

    // Override delay value, fixed backoff
    job.attempts(3).backoff( {delay: 60*1000, type:'fixed'} )

    // Enable exponential backoff using original delay (if set)
    job.attempts(3).backoff( {type:'exponential'} )

    // Use a function to get a customized next attempt delay value
    job.attempts(3).backoff( function( attempts, delay ){
      //attempts will correspond to the nth attempt failure so it will start with 0
      //delay will be the amount of the last delay, not the initial delay unless attempts === 0
      return my_customized_calculated_delay;
    })
 ```   
### User-Interface 
一个非常简洁的监控队列事件的ui:
默认端口3050：option.UIport配置,传-1（小于0的任意值）则关闭UI界面
127.0.0.1:3050

### use Cluster
通过多核的方式运行
```
var kue = require('kue')
  , cluster = require('cluster')
  , queue = kue.createQueue();

var clusterWorkerSize = require('os').cpus().length;

if (cluster.isMaster) {
  kue.app.listen(3000);
  for (var i = 0; i < clusterWorkerSize; i++) {
    cluster.fork();
  }
} else {
  queue.process('email', 10, function(job, done){
    var pending = 5
      , total = pending;

    var interval = setInterval(function(){
      job.log('sending!');
      job.progress(total - pending, total);
      --pending || done();
      pending || clearInterval(interval);
    }, 1000);
  });
}
```