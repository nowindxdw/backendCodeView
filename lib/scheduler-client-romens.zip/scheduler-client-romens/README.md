### scheduler的项目端

#### 关于scheduler-client

#### 使用方法
*引入项目
```
let schedulerClient = require("scheduler-client-romens")();
```

##### 循环执行离线任务:
```
return schedulerClient.taskPost(taskParams, cbParams)
    .then(function(data)){
        //....
    }
```

*参数说明
```
 //离线任务主任务参数
 var taskParams = {                         
    taskUrl:"http://0.0.0.0:3000/v1/task",  //离线任务微服务的地址和端口,通常写入项目的配置config文件中
    name   :"testName",                     //离线任务的任务名
    count  :1,                              //离线任务重复执行次数, 如果为0则表示不限次数
    cronJob:{                               //crontime的标准格式  用于循环执行任务
        "second": "0",
        "minute": "0",
        "hour": "0",
        "dom": "*",
        "month": "*",
        "dow": "*"
    },
    startAt:0,                              //Unix的时间戳,精确到秒
    stopAt :0,                              //Unix的时间戳,精确到秒
    isMultipleEntry:false                   //上次任务未完成时可否覆盖执行下一次任务
};
//离线任务回调参数
var cbParams = {
    url:"cbUrl",                            //回调地址,配置见下面回调处理             
    method:"POST",                          //回调方法,与地址配置保持一致,通常为POST,['GET', 'POST', 'PATCH', 'DELETE']
    params:"params"                         //回调的参数体,json字符串
};

```

##### 立即执行离线任务:

```
return schedulerClient.taskQuickPost(taskParams, cbParams)
    .then(function(data)){
        //....
    }
```

*参数说明
```
 //离线任务主任务参数
 var taskParams = {                         
    taskUrl:"http://0.0.0.0:3000/v1/task",  //离线任务微服务的地址和端口,通常写入项目的配置config文件中
    name   :"testName",                     //离线任务的任务名
    time  :"1490088784"                     //离线任务本次执行时间
};
//离线任务回调参数
var cbParams = {
    url:"cbUrl",                            //回调地址,配置见下面回调处理             
    method:"POST",                          //回调方法,与地址配置保持一致,POST,['GET', 'POST', 'PATCH', 'DELETE']
    params:"params"                         //回调的参数体,json字符串
};

```

##### 删除指定离线任务:

```
return schedulerClient.taskIdDelete(taskUrl, taskId)
    .then(function(data)){
        //....
    }
```

*参数说明
```                       
    taskUrl  : "http://0.0.0.0:3000/v1/task",  //离线任务微服务的地址和端口,通常写入项目的配置config文件中
    taskId   : "12499798081811720869",                     //离线任务的任务ID         
```


##### 异步离线任务结果通知:

```
return schedulerClient.taskStatusPost(taskUrl, taskToken,taskResult)
    .then(function(data)){
        //....
    }
```

*参数说明
```                       
    taskUrl     : "http://0.0.0.0:3000/v1/task",  //离线任务微服务的地址和端口,通常写入项目的配置config文件中
    taskToken   : "12499798081811720869",         //离线任务的任务TOKEN    
    taskResult  : {
                  status:'SUCCESS'
                  };,         //离线任务的返回结果格式固定，只允许传 (SUCCESS, FAILED)其中一个
```


##### 修改指定id离线任务:
```
return schedulerClient.taskIdPut(taskId,taskParams, cbParams)
    .then(function(data)){
        //....
    }
```

*参数说明
```
 var taskId   = "12499798081811720869",     //离线任务的任务ID        
 //离线任务主任务参数
 var taskParams = {                         
    taskUrl:"http://0.0.0.0:3000/v1/task",  //离线任务微服务的地址和端口,通常写入项目的配置config文件中
    name   :"testName",                     //离线任务的任务名
    count  :1,                              //离线任务重复执行次数, 如果为0则表示不限次数
    cronJob:{                               //crontime的标准格式  用于循环执行任务
        "second": "0",
        "minute": "0",
        "hour": "0",
        "dom": "*",
        "month": "*",
        "dow": "*"
    },
    startAt:0,                              //Unix的时间戳,精确到秒
    stopAt :0,                              //Unix的时间戳,精确到秒
    isMultipleEntry:false                   //上次任务未完成时可否覆盖执行下一次任务
};
//离线任务回调参数
var cbParams = {
    url:"cbUrl",                            //回调地址,配置见下面回调处理             
    method:"POST",                          //回调方法,与地址配置保持一致,通常为POST,['GET', 'POST', 'PATCH', 'DELETE']
    params:"params"                         //回调的参数体,json字符串
};

```

##### 查询任务定时器history属性:
```
return schedulerClient.taskListHistory(condition)
    .then(function(data)){
        //....
    }
```

*参数说明
```
var condition ={
    taskUrl:"http://0.0.0.0:3000/v1/task",   //离线任务微服务的地址和端口,通常写入项目的配置config文件中
    taskId:"12500304183108301333",           //离线任务的任务ID        
    beginAt:0,                               //离线任务的开始时间，Unix的时间戳,精确到秒   
    endAt:0,                                 //离线任务的结束时间，Unix的时间戳,精确到秒，暂不生效   
    pageNum:1,
    pageSize:10
};

```


#### 任务回调的处理:

*1 app.js加入回调接收:
```
//处理离线任务回调的中间件
var schedulerCaller = require(__base+'/models/schedulerCaller');
app.use(schedulerCaller('on'));
app.post('/scheduler/callback', function(req, res){
    res.send('received scheduler callback');
});
``` 

*2.schedulerCaller.js例子代码：
```
var jwt = require('jsonwebtoken');
var Logger = require("logger-romens");
var logger = new Logger();

// the middleware function\
/**
 * @module  schedulerCaller.js
 * @description jwt中间件调用module
 * @returns {Function}
 */
module.exports = function (onoff) {
    console.log(">>>>>>>>>>schedulerCaller is " + onoff + "<<<<<<<<<<<<");
    return function (req, res, next) {
        if (onoff !== 'on') {
            return next();
        }
        var callPath = /^\/scheduler\/callback/;
        if (!(callPath.test(req.path) && (req.method === 'POST'))) {
            return next();
        }
        logger.trace("enter into scheduler callback");
        //if err
        //return res.status(500).end('invalid msg');
        //if done
        return next();
    };

    /**
     * @func checkToken
     * @description 校验jwt token密码
     * @param token
     * @param callback
     */
    function checkToken(token, callback) {
        jwt.verify(token, __authConfig.secret, function (error, payload) {
            if (error) {
                console.log(error);
                return callback(error);
            }
            callback(null, payload);
        });
    }


};
```