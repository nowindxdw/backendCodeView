//mocha test
'use strict';
const expect = require('chai').expect;
const sinon = require('sinon');
const Logger = require('logger-romens');
const logger = new Logger();
const model = require('../base.js')();

describe("test scheduler-client", function () {

    before('before all test & called only once', function () {
        // console.log('before');
    });

    after('after all test & called only once', function () {
        // console.log('after');
    });

    beforeEach('called before each test', function () {
        // console.log('beforeEach');
    });

    afterEach('called after each test', function () {
        // console.log('afterEach');
    });

    describe("#base ()", function () {

        xit("将循环执行的离线任务数据同步至微服务: taskPost; ", function () {
            this.timeout(10000);
            var taskParams = {
                taskUrl:"http://0.0.0.0:3000/v1/task",
                name   :"testName",
                count  :1,
                cronJob:{
                    "second": "0",
                    "minute": "0",
                    "hour": "0",
                    "dom": "*",
                    "month": "*",
                    "dow": "*"
                },
                startAt:0,
                stopAt :0,
                isMultipleEntry:false
            };
            var cbParams = {
                url:"cbCircleUrl",
                method:"POST",
                params:"Circleparams"
            };

            return model.taskPost(taskParams, cbParams)
                .then(function(data){
                    logger.debug(data);
                    let taskId = data.taskId;
                    logger.trace("taskId",taskId);
                    expect(data).to.not.equal(null);
                })
                .catch(function(err){
                    expect(err).to.equal(null);
                });
        });

        xit("将一次执行的离线任务数据同步至微服务: taskQuickPost; ", function () {
            this.timeout(10000);
            var taskParams = {
                taskUrl:"http://0.0.0.0:3000/v1/task",
                name   :"testQuickName",
                time: "1490148000"   //2017.3.22 10.00.00
            };
            var cbParams = {
                url:"cbOnceUrl",
                method:"POST",
                params:"Onceparams"
            };

            return model.taskQuickPost(taskParams, cbParams)
                .then(function(data){
                    logger.debug(data);
                    let taskId = data.taskId;
                    logger.trace("taskId",taskId);
                    expect(data).to.not.equal(null);
                })
                .catch(function(err){
                    expect(err).to.equal(null);
                });
        });

        xit("将制定id的离线任务数据从微服务删除: taskIdDelete; ", function () {
            this.timeout(10000);
            let taskUrl="http://0.0.0.0:3000/v1/task";
            let taskId = '12499798081811720869';
            //let taskId = '123';
            return model.taskIdDelete(taskUrl, taskId)
                .then(function(data){
                    logger.debug(data);
                    expect(data).to.not.equal(null);
                })
                .catch(function(err){
                    expect(err).to.equal(null);
                });
        });

        xit("异步离线任务结果通知: taskStatusPost; ", function () {
            let taskUrl="http://0.0.0.0:3000/v1/task";
            let taskToken = '12500304191580796438';
            let taskResult = {
                status:'SUCCESS'//allowable value (SUCCESS, FAILED)
            };
            return model.taskStatusPost(taskUrl, taskToken,taskResult)
                .then(function(data){
                    logger.debug(data);
                    expect(data).to.not.equal(null);
                })
                .catch(function(err){
                    expect(err).to.equal(null);
                });
        });

        xit("查询任务定时器属性: taskListPost; ", function () {
            let condition ={
                taskUrl:"http://0.0.0.0:3000/v1/task",
                pageNum:1,
                pageSize:10
                //isMaxReached:true
            };
            return model.taskListPost(condition)
                .then(function(data){
                    logger.debug(data);
                    expect(data).to.not.equal(null);
                })
                .catch(function(err){
                    expect(err).to.equal(null);
                });
        });

        xit("修改离线任务配置参数: taskIdPut; ", function () {
            let taskId = '12500304182579816979';
            let taskParams = {
                taskUrl:"http://0.0.0.0:3000/v1/task",
                name   :"testName01",
                count  :2,
                cronJob:{
                    "second": "0",
                    "minute": "0",
                    "hour": "1",
                    "dom": "*",
                    "month": "*",
                    "dow": "*"
                },
                startAt:0,
                stopAt :0,
                isMultipleEntry:true
            };
            let cbParams = {
                url:"NewcbCircleUrl",
                method:"POST",
                params:"NewCircleparams"
            };
            return model.taskIdPut(taskId, taskParams, cbParams)
                .then(function(data){
                    logger.debug(data);
                    expect(data).to.not.equal(null);
                })
                .catch(function(err){
                    expect(err).to.equal(null);
                });
        });

        xit("查询任务定时器history属性: taskListHistory; ", function () {
            let condition ={
                taskUrl:"http://0.0.0.0:3000/v1/task",
                taskId:"12500304183108301333",
                beginAt:0,
                endAt:0,
                pageNum:1,
                pageSize:10
            };
            return model.taskListHistory(condition)
                .then(function(data){
                    logger.debug(data);
                    expect(data).to.not.equal(null);
                })
                .catch(function(err){
                    expect(err).to.equal(null);
                });
        });

    });
})
