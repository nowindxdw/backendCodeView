/*****************************************************************
 * 青岛雨人软件有限公司©2016版权所有
 *
 * 本软件之所有（包括但不限于）源代码、设计图、效果图、动画、日志、
 * 脚本、数据库、文档均为青岛雨人软件或其附属子公司所有。任何组织
 * 或者个人，未经青岛雨人软件书面授权，不得复制、使用、修改、分发、
 * 公布本软件的任何部分。青岛雨人软件有限公司保留对任何违反本声明
 * 的组织和个人采取法律手段维护合法权益的权利。
 *****************************************************************/
'use strict';

const Logger = require('logger-romens');
const logger = new Logger();
const superAgent = require('superagent');
const _ = require('lodash');
const RomensAgent = require('./lib/romensAgent');
const romensAgent = new RomensAgent();
module.exports = function(){

  let scheduleClient = {
      /**
       * 创建循环执行离线任务
       * @param taskParams
       * @param cbParams
       */
      taskPost: (taskParams, cbParams) => new Promise(function(resolve, reject) {
          logger.trace('enter taskPost.');
          var reqData = {
              taskName: taskParams.name,
              cronJobValue: taskParams.cronJob,
              repeatTimes: taskParams.count,
              startAt: taskParams.startAt,
              stopAt: taskParams.stopAt,
              isMultipleEntry: taskParams.isMultipleEntry,
              callbackUrl: cbParams.url,
              callbackMethod: cbParams.method,
              callbackParams: cbParams.params,
              callbackContentType: 'application/json',
              callbackAsync: true   //true代表异步;false代表同步
          };
          logger.debug('create task req: ' + JSON.stringify(reqData));
          logger.debug('taskUrl: ' + taskParams.taskUrl);

          superAgent.post(taskParams.taskUrl)
              .send(reqData)
              .set('content-type', 'application/json')
              .set('Accept', 'application/json')
              .end((error, result) => {
                  if(error || _.isUndefined(result)) {
                      let err  = error.response ? error.response.text : 'task post response is undefined.';
                      logger.error(err);
                      return reject(err);
                  }
                  try {
                      result = JSON.parse(result.text);
                  }
                  catch (err) {
                      logger.error(err.stack);
                      return reject(err.stack);
                  }
                  logger.debug('taskPost result: ' + JSON.stringify(result));
                  resolve(result);
              });

      }),

      /**
       * 创建一次性任务
       * @param taskParams
       * @param cbParams
       */
      taskQuickPost: (taskParams, cbParams) => new Promise(function(resolve, reject) {
        logger.trace('enter taskQuickPost.');
        var quickPostUrl = taskParams.taskUrl + '/quick';
        var reqData = {
          taskName: taskParams.name,
          timeValue: taskParams.time,
          callbackUrl: cbParams.url,
          callbackMethod: cbParams.method,
          callbackParams: cbParams.params,
          callbackContentType: 'application/json',
          callbackAsync: true    //true代表异步;false代表同步
        };
        logger.debug('create task req: ' + JSON.stringify(reqData));
        logger.debug('quickPostUrl: ' + quickPostUrl);
        superAgent.post(quickPostUrl)
          .send(reqData)
          .set('content-type', 'application/json')
          .set('Accept', 'application/json')
          .end((error, result) => {
            if(error || _.isUndefined(result)) {
              let err  = error.response ? error.response.text : 'taskQuick post response is undefined.';
              logger.error(err);
              return reject(err);
            }
            try {
              result = JSON.parse(result.text);
            }
            catch (err) {
              logger.error(err.stack);
              return reject(err.stack);
            }
            logger.debug('taskQuickPost result: ' + JSON.stringify(result));
            resolve(result);
          });

      }),

      /**
       * 删除离线任务  实际在微服务端标记该id的任务为‘删除’状态
       * @param taskUrl
       * @param taskId
       */
      taskIdDelete: (taskUrl,taskId) => new Promise(function(resolve, reject) {
        logger.trace('enter taskIdDelete.');
        var delTaskUrl = taskUrl + '/' + taskId;
        romensAgent.sendJson("del", delTaskUrl, {}, function(err, result) {
          if(err) {
            logger.error(err);
            return reject(err);
          }
          logger.debug('delete resData:: ' + JSON.stringify(result));
          resolve(result);
        });
      }),

      /**
       * 异步离线任务结果通知
       * @param taskUrl
       * @param taskToken
       * @param taskResult {status, message}
       */
      taskStatusPost: (taskUrl, taskToken, taskResult) => new Promise((resolve, reject) => {
        logger.trace('enter taskStatusPost.');

        var taskStatusUrl = taskUrl + '/status/' + taskToken + '?status=' + taskResult.status;
        logger.debug('taskStatusUrl: ' + taskStatusUrl);
        romensAgent.sendJson("post", taskStatusUrl, taskResult.message, function(err, result) {
          if(err) {
            logger.error(err);
            return reject(err);
          }
          logger.debug('task status post: ' + JSON.stringify(result));
          resolve(result);
        });
      }),

      /**
       * 查询任务定时器属性
       * @param condition {isDeleted, isExpired,isMaxReached, pageNum, pageSize}
       * @constructor
       */
      taskListPost: (condition) => new Promise((resolve, reject) => {
          logger.trace('enter taskListPost.');

          var taskListPostUrl = condition.taskUrl + '/list';
          condition.pageNum = condition.pageNum || 1;
          condition.pageSize = condition.pageSize || 10;

          logger.debug('TaskIdGet req: ' + JSON.stringify(condition));
          logger.debug('TaskIdGetUrl: ' + taskListPostUrl);

          romensAgent.sendJson('post', taskListPostUrl, condition, function(err, result) {
              if(err) {
                  logger.error(err);
                  return reject(err);
              }

              try {
                  result = JSON.parse(result);
              }
              catch(err) {
                  logger.error(err.stack);
                  return reject(err.stack);
              }
              resolve(result);
          });

      }),

      /**
       * 修改离线任务配置参数
       * @param taskId
       * @param taskParams
       * @param cbParams
       */
      taskIdPut: (taskId, taskParams, cbParams) => new Promise((resolve, reject) => {
        logger.trace('enter taskIdPut.');

        var reqData = {
          taskName: taskParams.name,
          cronJobValue: taskParams.cronJob,
          repeatTimes: taskParams.count,
          startAt: taskParams.startAt,
          stopAt: taskParams.stopAt,
          isMultipleEntry: true,
          callbackUrl: cbParams.url,
          callbackMethod: cbParams.method,
          callbackParams: cbParams.params,
          callbackContentType: 'application/json',
          callbackAsync: true
        };
        var taskIdPutUrl = taskParams.taskUrl + '/' + taskId;

        logger.debug('taskIdPut req: ' + JSON.stringify(reqData));
        logger.debug('taskIdPutUrl: ' + taskIdPutUrl);

        romensAgent.sendJson('put', taskIdPutUrl, reqData, function(err, result) {
          if(err) {
            logger.error(err);
            return reject(err);
          }
          logger.debug('task put: ' + JSON.stringify(result));
          resolve(result);
        });

      }),

      /**
       * 查询任务历史属性
       * @param condition {taskUrl,taskId, beginAt,endAt, pageNum, pageSize}
       * @constructor
       */
      taskListHistory: (condition) => new Promise((resolve, reject) => {
          logger.trace('enter taskListHistory.');

          var taskListHistoryUrl = condition.taskUrl +'/'+condition.taskId +'/history';
          var search = {};
          search.beginAt  = condition.beginAt || '';
          search.endAt    = condition.endAt   || '';
          search.pageNum  = condition.pageNum || 1;
          search.pageSize = condition.pageSize|| 10;
          logger.debug('TaskIdGet req: ' + JSON.stringify(condition));
          logger.debug('TaskIdGetUrl: ' + taskListHistoryUrl);
          romensAgent.sendJson('get', taskListHistoryUrl, condition, function(err, result) {
              if(err) {
                  logger.error(err);
                  return reject(err);
              }
              try {
                  result = JSON.parse(result);
              }
              catch(err) {
                  logger.error(err.stack);
                  return reject(err.stack);
              }
              resolve(result);
          });

      })
  };
  return  scheduleClient;
};





