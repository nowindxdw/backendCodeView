# redis-connection-factory-romens

用来获取和存储redis连接的模块.

##### 作者:zhaopeng
## user guide
### install

先确保npm使用了雨诺的私有源.如果npm没有指向成都雨诺的私有源,请执行下面命令(其中地址信息请先确认):
```shell
npm set registry http://192.168.100.1:4873
```
### use

```javascript
var RedisConnectionFactory = require('redis-connection-factory-romens');

var option = {
  "host" :'localhost',
  "port": 1234,
  "password": '1234',
  "database-number": 10
};
var redisConnection = RedisConnectionFactory.getRedisConnection(option);
```
* 其中option中的`password`是可选项.

* `RedisConnectionFactory`会在初次调用`getRedisConnection`方法的时候创建一个数据库连接.并将连接保存下来.
以后每次调用`getRedisConnection`方法,我们将会达到同一个connection.

* 在非初次调用的情况下`getRedisConnection`方法可以省略option参数.
