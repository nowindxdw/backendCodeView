var redis = require('redis');

var redisConnectionRef = null;

var getRedisConnection = function (redisConfig) {
  if (redisConnectionRef) {
    return redisConnectionRef;
  }

  var redisServerPort = redisConfig.port;
  var redisServerHost = redisConfig.host;
  var redisServerPass = redisConfig.password;
  var redisServerDbNumber = redisConfig['database-number'];

  // 链接redis
  var redisClient = redis.createClient(redisServerPort, redisServerHost);

  // 验证密码
  if (redisServerPass) {
    redisClient.auth(redisServerPass);
  }

  // 选则redis的DB号
  redisClient.select(redisServerDbNumber);

  redisConnectionRef = redisClient;
  return redisConnectionRef
};

var redisConnectionFactory = {
  getRedisConnection: getRedisConnection
};

module.exports = redisConnectionFactory;

