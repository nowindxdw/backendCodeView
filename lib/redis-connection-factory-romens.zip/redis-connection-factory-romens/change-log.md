# redis-connection-factory

## v1.0.0 2016-09-20
创建了redis-connection-factory库
